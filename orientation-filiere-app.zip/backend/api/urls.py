from django.urls import path
from .views import OrientationView

urlpatterns = [
    path('orientation/', OrientationView.as_view()),
]
